from . import test_project_apartment
from . import test_sale
from . import test_pricelist
# from . import test_purchase
# from . import test_intercompany
# from . import test_exhibition
# from . import test_direct_supplier
