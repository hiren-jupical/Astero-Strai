from enum import Enum


class Company(Enum):
    StraiKjokkenKristiansand = 7
