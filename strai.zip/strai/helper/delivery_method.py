from enum import Enum


class DeliveryMethod(Enum):
    DeliverToCustomer = 1
    DeliverToShop = 2
