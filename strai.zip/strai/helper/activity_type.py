from enum import Enum


class ActivityType(Enum):
    ChangedAfterConfirmation = 21
