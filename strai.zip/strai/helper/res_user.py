from enum import Enum


class ResUser(Enum):
    Trunk = 2875
