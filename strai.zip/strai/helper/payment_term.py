from enum import Enum


class PaymentTerm(Enum):
    Days30 = 4
