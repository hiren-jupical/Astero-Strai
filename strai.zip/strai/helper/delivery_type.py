from enum import Enum


class DeliveryType(Enum):
    Regular = 1
    SmallTruck = 2
