from . import winner_ref_wizard
from . import crm_lead_lost
# from . import stock_immediate_transfer
from . import sale_invoice
from . import mail_compose_message
